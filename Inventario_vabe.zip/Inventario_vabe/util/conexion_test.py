from util.conexion import Conexion

db = Conexion(host = 'localhost', port = 3306 , user = 'root' , password= ""  , database= 'inventario_vabe')
db.connect(db)