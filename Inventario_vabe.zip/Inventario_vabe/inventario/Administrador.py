"""""from util.conexion import Conexion
from fastapi import FastAPI, Body
from fastapi.responses import HTMLResponse
#app = FastAPI()

db = Conexion(host='localhost', port=3306, user='root', password="", database='inventario_vabe')
db.connect()


class Administrador:

    def __init__(self, id_admin, nombre_completo_admin, email, clave):
        self._id_admin =id_admin
        self._nombre_completo_admin = nombre_completo_admin
        self._email = email
        self._clave = clave


    @property
    def id_admin(self):
        return self._id_admin

    @id_admin.setter
    def id_admin(self, id_admin):
        self._id_admin =id_admin

    @property
    def nombre_completo_admin(self):
        return self._nombre_completo_admin

    @nombre_completo_admin.setter
    def nombre_completo_admin(self, nombre_completo_admin):
     self._nombre_completo_admin = nombre_completo_admin

    @property
    def email (self):
        return self._email

    @email .setter
    def email (self, email):
        self._email = email

    @property
    def clave(self):
        return self._clave

    @clave.setter
    def email(self, clave):
      self._clave = clave



    @app.post('/crear_admin/{id_admin, nombre_completo_admin, email, clave}', tags=["Crear administrador"])
    def crear_admin(id_admin: int=Body(), nombre_completo_admin: str=Body(), email:str=Body(), clave:int=Body()):
       query= "INSER INTO administrador (id_admin, nombre_completo_admin, email, clave) VALUES (%S, %S, %S, %S)"
       values = (id_admin, nombre_completo_admin, email, clave,)
       db.execute_query(query, values,)


    @app.post('/iniciar_sesion/{email, clave}', tags=["Iniciar sesion"])
    def iniciar_sesion(email:str=Body(), clave:int=Body()):
        query = "SELECT * FROM administrador WHERE email = %s AND clave = %s"
        values = (email, clave)
        result = db.execute_query(query, values)

        if result:
            return result

        else:
           
         print("Correo electrónico o clave incorrectos")


    @staticmethod
    @app.get('/ver_administradores/', tags=["Ver administradores"])
    def ver_administradores():
        query = "SELECT * FROM administrador"
        result = db.execute_query(query)
        if result:
            return  result
        else:
            print("Administradora No encontrado")
            return []


    @app.delete('/eliminar_administradores/{id_admin}', tags=["Eliminar administradores"])
    def eliminar_administradores(id_admin):
        query = "DELETE FROM administrador WHERE id_admin = %s"
        db.execute_query(query, (id_admin,))
"""""


