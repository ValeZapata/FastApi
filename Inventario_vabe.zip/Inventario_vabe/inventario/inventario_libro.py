from util.conexion import Conexion
from fastapi import FastAPI, Body
app = FastAPI()
db = Conexion(host='localhost', port=3306, user='root', password="", database='inventario_vabe')
db.connect()




@app.post('/agregar_libro/{id_libro, titulo, autor, editorial, año}', tags=["Agregar libro"])
def agregar_libro(id_libro:int=Body(), titulo:str=Body(), autor:str=Body(), editorial:str=Body(), year:int=Body()):
        query = "INSERT INTO libros(id_libro,titulo, autor, editorial, año) VALUES(%s, %s, %s, %s,%s)"
        values = (id_libro, titulo, autor, editorial, year,)
        db.execute_query(query, values,)


@app.get('/observar_libros/', tags=["Observar libros"])
def observar_libros():
        query = "SELECT * FROM libros"
        result = db.execute_query(query)

        if result:
            return result  # Este return debe estar fuera del bucle for
        else:
            print("No hay libros")
            return []

@app.delete('/eliminar_libros/{id_libro}', tags=["Eliminar producto"])
def eliminar_libro(id_libro):
        query = "DELETE FROM libros WHERE id_libro = %s"
        db.execute_query(query, (id_libro,))

@app.put('/actualizar_libro/{id_libro, titulo, autor, editorial, año}', tags=["Actualizar libro"])
def actualizar_libro(id_libro:int=Body(), titulo:str=Body(), autor:str=Body(), editorial:str=Body(), year:int=Body()):
        query = f"UPDATE libros SET titulo = '{titulo}' , autor = '{autor}', editorial = '{editorial}', año = {year} WHERE id_libro = {id_libro};"
        return db.execute_query(query)