from util.conexion import Conexion
from inventario.inventario_libro import Libros
from inventario.Administrador import Administrador
from inventario.menu_inventario import menu_inventario


db = Conexion(host='localhost',port=3306, user='root',password="",database='inventario_vabe')
db.connect()


administrador  =Administrador (None,None,None,None)
libros = Libros(None,None,None,None,None)
menu = menu_inventario()

class menu_principal():
    while True:
      print("\nMenú:")
      print("1. Crear administradora")
      print("2. Iniciar sesión")
      print("3. Ver administradoras ")
      print("4. Eliminar administradora")
      print("5. Salir")


      opcion = input("Seleccione una opción☑: ")

      if opcion == '1':
       administrador.crear_admin(db)
      elif opcion == '2':
          if administrador.iniciar_sesion(db):
           menu.menu_inventario_libros()
          else:
           print("Selección no válida. Vuelve a intentarlo☹️")
      elif opcion == '3':
          administrador.ver_administradores()
      elif opcion == '4':
          administrador.ver_administradores()
          id_admin = int(input("Ingrese el ID del administrador que desea eliminar:\n"))
          administrador.eliminar_administradores(id_admin)
      elif opcion == '5':
          print("Saliste del menu 🤗")
          break
      else:
          print("Selección no válida. Vuelve a intentarlo☹️")