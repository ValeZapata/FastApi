from util.conexion import Conexion
from inventario.inventario_libro import Libros
#from inventario.Administrador import Administrador


db = Conexion(host='localhost', port=3306, user='root', password="",database='inventario_vabe')
db.connect()
#administrador = Administrador(None,None,None,None)
libros = Libros(None,None,None,None,None)

class menu_inventario:
 def menu_inventario_libros(self):
     while True:
        print("\nBienvenida a la Librería")
        print("1. Agregar libro")
        print("2. Observar libros")
        print("3. Actualizar libro")
        print("4. Eliminar libro")
        print("5. Salir")

        opcion = input("Seleccione una opción☑: ")

        if opcion == '1':
            libros.agregar_libro(db)
        elif opcion == '2':
            libros.observar_libros()
        elif opcion == '3':
            libros.observar_libros()
            id_libro = int(input("Ingrese el ID del libro que desea actualizar:\n"))
            libros.actualizar_libro(id_libro)
        elif opcion == '4':
            libros.observar_libros()
            id_libro = int(input("Ingrese el ID del libro que desea eliminar:\n"))
            libros.eliminar_libro(id_libro)
        elif opcion == '5':
            print("Saliste del inventario de la Libreria  🤗")
            break
        else:
            print("Selección no válida. Vuelve a intentarlo☹️")